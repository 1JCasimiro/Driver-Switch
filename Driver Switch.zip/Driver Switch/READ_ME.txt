*  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  
*										
*	THIS SOFTWARE DOES NOT WORK WITHOUT SETTING IT UP FIRST				                                
*												                       
*		- This program makes it simple to change your tablet drivers, everytime you switch tablet brands.
*												                   
*	HOW TO SETUP
*												  
*	\\\ Everytime that you install a new brand driver, it overrides the wintab32.dll file in the System32 folder. 
*	\\\ Location of wintab32.dll file: C:\Windows\System32						               
*												                        
*		- Download your tablet 1 drivers and save the wintab32.dll on the brand 1 folder;			
*		- Download your tablet 2 drivers and save the wintab32.dll on the brand 2 folder;			
*		- Do the same to other brands if you own any;								
*															
*	INSTRUCTIONS TO USE AFTER SETUP									
*															
*	1 - Run Driver Switch.exe and write the name of the brand you want to use. 					
*															
*	\\\ EXTRA - If you have another brand or more than one config .dll file, you can make a new folder and use the  
*	name of that folder as a command in prompt.									
*												                        
*	OBS: If it doesnt work right away, reboot the computer.											                        
*												                        
*  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  